package com.example.googlebooks

import android.content.Intent
import android.net.Uri
import androidx.recyclerview.widget.RecyclerView
import com.example.googlebooks.databinding.ListItemLayoutBinding

class BookViewHolder(val binding: ListItemLayoutBinding) : RecyclerView.ViewHolder(binding.root) {

    private lateinit var currentBook : Book

    init {
        binding.root.setOnClickListener { view ->
            val bookUri = Uri.parse(currentBook.url)
            val websiteIntent = Intent(Intent.ACTION_VIEW, bookUri)
            itemView.context.startActivity(websiteIntent)
        }
    }

    fun bindBook(book: Book) {
        currentBook = book
        binding.titleTextview.text = book.title
        binding.subtitleTextview.text = book.subtitle
        binding.authorTextview.text = book.authors.toString()
    }

}