package com.example.googlebooks

import androidx.recyclerview.widget.RecyclerView
import com.example.googlebooks.databinding.ListItemLayoutBinding

class BookViewHolder(val binding: ListItemLayoutBinding) : RecyclerView.ViewHolder(binding.root) {

    private lateinit var currentBook : Book

    fun bindBook(book: Book) {
        currentBook = book
        binding.titleTextview.text = book.title
        binding.subtitleTextview.text = book.subtitle
        binding.authorTextview.text = book.authors.toString()
    }

}