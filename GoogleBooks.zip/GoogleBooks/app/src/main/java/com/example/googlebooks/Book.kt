package com.example.googlebooks

data class Book(var title: String, var subtitle: String?, var authors: List<String>, var url: String) {}