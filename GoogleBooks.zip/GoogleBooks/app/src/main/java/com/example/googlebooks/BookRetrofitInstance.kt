package com.example.googlebooks

import retrofit2.Retrofit
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import retrofit2.converter.moshi.MoshiConverterFactory


private const val bookapibase = "https://www.googleapis.com/books/v1/"

val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

class BookRetrofitInstance {
    val retrofitObject = Retrofit.Builder().baseUrl(bookapibase).addConverterFactory(
        MoshiConverterFactory.create(moshi)).build()
    val bookApi = retrofitObject.create(BookApiInterface::class.java)

}