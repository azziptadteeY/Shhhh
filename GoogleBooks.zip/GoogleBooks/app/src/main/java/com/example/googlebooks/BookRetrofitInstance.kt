package com.example.googlebooks

import retrofit2.Retrofit
import retrofit2.converter.scalars.ScalarsConverterFactory

private const val bookapibase = "https://www.googleapis.com/books/v1/"

class BookRetrofitInstance {
    val retrofitObject = Retrofit.Builder().baseUrl(bookapibase).addConverterFactory(
        ScalarsConverterFactory.create()).build()
    val bookApi = retrofitObject.create(BookApiInterface::class.java)

}