package com.example.googlebooks

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.googlebooks.databinding.ListItemLayoutBinding

class BookAdapter(val bookList : List<Book>) : RecyclerView.Adapter<BookViewHolder>() {

    private val viewModel: BookViewModel by viewModels()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BookViewHolder {
        val binding = ListItemLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return BookViewHolder(binding)
    }

    override fun onBindViewHolder(holder: BookViewHolder, position: Int) {
        val currentBook = bookList[position]
        holder.bindBook(currentBook)

    }

    override fun getItemCount(): Int {
        return bookList.size
    }

}