package com.example.googlebooks

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class BookViewModel : ViewModel() {

    private val _response = MutableLiveData<List<Book>>()
    val response: MutableLiveData<List<Book>>
        get() = _response

    fun getBooks() {
        val request:Call<BooksResponse> = BookRetrofitInstance().bookApi.getBooksRequest()

        request.enqueue(object: Callback<BooksResponse> {
            override fun onResponse(call: Call<BooksResponse>, response: Response<BooksResponse>) {
                val listOfBooksGotten = mutableListOf<Book>()

                val booksResponse: BooksResponse? = response.body()
                val bookInformationList = booksResponse?.bookInformationList ?: listOf()
                for (bookInformation in bookInformationList) {

                    val bookProperties = bookInformation.bookProperties

                    val title = bookProperties.title
                    val subtitle = bookProperties.subtitle
                    val authors = bookProperties.authors
                    val url = bookProperties.url

                    val newBook = Book(title, subtitle, authors, url)
                    listOfBooksGotten.add(newBook)

                }
                _response.value = listOfBooksGotten

                Log.d("RESPONSE", response.body().toString())

            }

            override fun onFailure(call: Call<BooksResponse>, t: Throwable) {
                Log.d("RESPONSE", t.message.toString())
            }

        })

    }

}