package com.example.googlebooks

import android.util.Log
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class BookViewModel {

    fun getBooks() {
        val request = BookRetrofitInstance().bookApi.getBooksRequest()

        request.enqueue(object: Callback<String> {
            override fun onResponse(call: Call<String>, response: Response<String>) {
                Log.d("RESPONSE", response.body().toString())
            }

            override fun onFailure(call: Call<String>, t: Throwable) {
                Log.d("RESPONSE", t.message.toString())
            }

        })

    }

}