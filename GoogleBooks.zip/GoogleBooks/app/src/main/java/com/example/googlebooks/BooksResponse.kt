package com.example.googlebooks

import com.squareup.moshi.Json

class BooksResponse {

    @Json(name = "items")
    lateinit var bookInformationList: List<BookFeatures>
}

class BookFeatures {
    @Json(name = "volumeInfo")
    lateinit var bookProperties: BookProperties
}
class BookProperties {
    @Json(name = "title")
    var title: String = ""

    @Json(name = "subtitle")
    var subtitle: String? = ""

    @Json(name = "authors")
    var authors: List<String> = listOf()

    @Json(name = "infoLink")
    lateinit var url: String
}