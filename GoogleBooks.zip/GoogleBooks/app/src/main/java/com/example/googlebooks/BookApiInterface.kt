package com.example.googlebooks

import retrofit2.Call
import retrofit2.http.GET

private const val booksapirel : String = "volumes?q=android&maxResults=12&key=AIzaSyAI1zZfQaLFBHFbr3T9ghLwcXaGUJd6r1c"
interface BookApiInterface {

    @GET(booksapirel)
    fun getBooksRequest() : Call<BooksResponse>

}