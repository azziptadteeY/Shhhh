package com.example.googlebooks

import retrofit2.Call
import retrofit2.http.GET

private const val booksapirel : String = "volumes?q=beans&startIndex=0&maxResults=10"
interface BookApiInterface {

    @GET(booksapirel)
    fun getBooksRequest() : Call<String>

}